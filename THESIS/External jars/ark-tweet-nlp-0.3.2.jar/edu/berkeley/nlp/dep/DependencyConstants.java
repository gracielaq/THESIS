package edu.berkeley.nlp.dep;

public interface DependencyConstants {
	public static final String BOUNDARY_WORD = "$$";
}
