package edu.berkeley.nlp.util.functional;

/**
 * Created by IntelliJ IDEA.
* User: aria42
* Date: Oct 9, 2008
* Time: 6:31:50 PM
*/
public interface Predicate<I> extends Function<I,Boolean> {}
