package edu.berkeley.nlp.mapper;

/**
 * User: aria42
* Date: Feb 19, 2009
*/
public interface SimpleMapper<T> {
  public void map(T elem);
}
