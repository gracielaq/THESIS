package edu.berkeley.nlp.math;

public interface Normalizer {
	double[] normalize(double[] x);
}
