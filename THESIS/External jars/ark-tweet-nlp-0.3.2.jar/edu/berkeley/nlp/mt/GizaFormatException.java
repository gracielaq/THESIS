/**
 * 
 */
package edu.berkeley.nlp.mt;

/**
 * @author Alexandre Bouchard
 *
 */
public class GizaFormatException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8346722357116482194L;

	public GizaFormatException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public GizaFormatException(String arg0, Throwable arg1)
	{
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public GizaFormatException(String arg0)
	{
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public GizaFormatException(Throwable arg0)
	{
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
