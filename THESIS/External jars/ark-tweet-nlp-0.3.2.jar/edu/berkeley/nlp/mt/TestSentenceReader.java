package edu.berkeley.nlp.mt;

public class TestSentenceReader {

}
