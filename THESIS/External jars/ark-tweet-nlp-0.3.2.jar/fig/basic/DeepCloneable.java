package fig.basic;

public interface DeepCloneable<T> {
  public T deepClone();
}

