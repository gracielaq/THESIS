package fig.basic;

public class BooleanRef {
  public boolean value;
  public BooleanRef() { this.value = false; }
  public BooleanRef(boolean value) { this.value = value; }
  public String toString() { return ""+value; }
}
