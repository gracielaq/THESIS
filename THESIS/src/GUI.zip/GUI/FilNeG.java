package GUI;

import Classifier.SVM.Classifier;
import Classifier.SVM.Train;
import liblinear.Linear;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

/**
 * Created by gracielaquiambao on 10/12/16.
 */
public class FilNeG extends JFrame {

    private JPanel filnegPane;
    private JButton earthquakeButton;
    private JTextArea svmAccu;
    private JTextArea news;
    private JButton button1;
    private JButton typhoonButton;
    private JButton floodButton;
    private JButton backButton;


    public FilNeG(){
        setContentPane(filnegPane);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);

        String text=news.getText();

        //SVM ACCURACY OF CLASSIFICATION
        try {
            Train train=new Train();
            Classifier classifier=new Classifier();
            Linear acc=new Linear();
            svmAccu.append("\n"+train.trainTime+"\n");
            svmAccu.append(train.testTime+"\n");
            svmAccu.append(classifier.inst+"\n");
            svmAccu.append(acc.accuracy);

        }
        catch(Exception except){
            except.printStackTrace();
        }

        //Earthquake Button
        earthquakeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                news.setText("");
                File[] earthquakeFiles=new File("EarthquakeNewsReport").listFiles();
                news.append("\n\nNEWS: EARTHQUAKE" + "\n ================================================");
                for(File textFile:earthquakeFiles){
                    try {
                        BufferedReader bufferedReader = new BufferedReader(new FileReader(textFile));

                        String line ="";
                        while((line=bufferedReader.readLine())!=null){

                            news.append("\n"+line+"\n");
                        }
                        bufferedReader.close();

                    } catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }
            }
        });

        //Typhoon Button
        typhoonButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                news.setText("");
                File[] typhoonFiles=new File("TyphoonNewsReport").listFiles();
                news.append("\n\nNEWS: TYPHOON" + "\n ================================================");
                for(File textFile:typhoonFiles){
                    try {
                        BufferedReader bufferedReader = new BufferedReader(new FileReader(textFile));

                        String line ="";
                        while((line=bufferedReader.readLine())!=null){

                            news.append("\n"+line+"\n");
                        }
                        bufferedReader.close();

                    } catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }
            }
        });

        //FLOOD BUTTON
        floodButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                news.setText("");
                File[] floodFiles=new File("FloodNewsReport").listFiles();
                news.append("\n\nNEWS: FLOOD" + "\n ================================================");
                for(File textFile:floodFiles){
                    try {
                        BufferedReader bufferedReader = new BufferedReader(new FileReader(textFile));

                        String line ="";
                        while((line=bufferedReader.readLine())!=null){

                            news.append("\n"+line+"\n");
                        }
                        bufferedReader.close();

                    } catch (Exception exception) {
                        exception.printStackTrace();
                    }
                }
            }
        });


    }

    public static void main(String[] args) {
        FilNeG main = new FilNeG();
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
